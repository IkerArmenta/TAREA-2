#lang racket

;; Procedimientos: la clausura. apply-procedure vive en interp.rkt, porque
;; evalúa el cuerpo con value-of.

(require "ast.rkt")

(provide
 (contract-out
  ;; La vinculación dinámica solo necesita el parámetro y el cuerpo
  [struct closure ([x symbol?]
                   [body expression?])]))

(struct closure (x body) #:transparent)
